namespace SimpleCalculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Result_textBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void calculate_button_Click(object sender, EventArgs e)
        {
            //Read input from the textboxes
            double number1 = double.Parse(firstNumber_textBox.Text);
            double number2 = double.Parse(secondNumber_textBox.Text);

            //Perform addition
            double result = number1 + number2;

            //Display the result in the third text box
            Result_textBox.Text = result.ToString();
            lastCalculation_label.Text = $"History: {result:F2}";

        }

        private void exit_button_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Do you want to close this window?", "Close", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                this.Close();
            }

        }

        private void subtract_Button_Click(object sender, EventArgs e)
        {
            //Read input from the textboxes
            double number1 = double.Parse(firstNumber_textBox.Text);
            double number2 = double.Parse(secondNumber_textBox.Text);

            //Perform subtraction
            double result = number1 - number2;

            //Display the result in the third text box
            Result_textBox.Text = result.ToString();
            lastCalculation_label.Text = $"History: {result:F2}";
        }

        private void multipy_Button_Click(object sender, EventArgs e)
        {
            //Read input from the textboxes
            double number1 = double.Parse(firstNumber_textBox.Text);
            double number2 = double.Parse(secondNumber_textBox.Text);

            //Perform multiplication
            double result = number1 * number2;

            //Display the result in the third text box
            Result_textBox.Text = result.ToString();
            lastCalculation_label.Text = $"History: {result:F2}";
        }

        private void divide_Button_Click(object sender, EventArgs e)
        {

            //Read input from the textboxes
            double number1 = double.Parse(firstNumber_textBox.Text);
            double number2 = double.Parse(secondNumber_textBox.Text);

            //Perform division
            double result = number1 / number2;

            if (number2 == 0)
            {
                MessageBox.Show("Please enter a valid number. You cannot divide by zero", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                //Display the result in the third text box
                Result_textBox.Text = result.ToString();
                lastCalculation_label.Text = $"History: {result:F2}";
            }
        }

        private void clear_button_Click(object sender, EventArgs e)
        {
            firstNumber_textBox.Text = "";
            secondNumber_textBox.Text = "";
            Result_textBox.Text = "";

        }

        private void firstNumber_textBox_TextChanged(object sender, EventArgs e)
        {
            if (!System.Text.RegularExpressions.Regex.IsMatch(firstNumber_textBox.Text, "^[0-9 , .]*$"))
            {
                MessageBox.Show("Please enter only numbers.");
                firstNumber_textBox.Text = " ";
            }

         }

        private void secondNumber_textBox_TextChanged(object sender, EventArgs e)
        {
            if (!System.Text.RegularExpressions.Regex.IsMatch(secondNumber_textBox.Text, "^[0-9 , .]*$"))
            {
                MessageBox.Show("Please enter only numbers.");
                secondNumber_textBox.Text = " ";
            }
        }
    }
}
