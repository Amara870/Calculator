﻿namespace SimpleCalculator
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            firstNumber_textBox = new TextBox();
            secondNumber_textBox = new TextBox();
            Result_textBox = new TextBox();
            add_Button = new Button();
            exit_button = new Button();
            subtract_Button = new Button();
            multipy_Button = new Button();
            divide_Button = new Button();
            lastCalculation_label = new Label();
            clear_button = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(218, 108);
            label1.Margin = new Padding(2, 0, 2, 0);
            label1.Name = "label1";
            label1.Size = new Size(160, 25);
            label1.TabIndex = 0;
            label1.Text = "Enter First Number";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(191, 174);
            label2.Margin = new Padding(2, 0, 2, 0);
            label2.Name = "label2";
            label2.Size = new Size(186, 25);
            label2.TabIndex = 1;
            label2.Text = "Enter Second Number";
            label2.Click += label2_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(318, 288);
            label3.Margin = new Padding(2, 0, 2, 0);
            label3.Name = "label3";
            label3.Size = new Size(59, 25);
            label3.TabIndex = 2;
            label3.Text = "Result";
            // 
            // firstNumber_textBox
            // 
            firstNumber_textBox.Location = new Point(559, 108);
            firstNumber_textBox.Margin = new Padding(2);
            firstNumber_textBox.Name = "firstNumber_textBox";
            firstNumber_textBox.Size = new Size(150, 31);
            firstNumber_textBox.TabIndex = 3;
            firstNumber_textBox.TextChanged += firstNumber_textBox_TextChanged;
            // 
            // secondNumber_textBox
            // 
            secondNumber_textBox.Location = new Point(559, 174);
            secondNumber_textBox.Margin = new Padding(2);
            secondNumber_textBox.Name = "secondNumber_textBox";
            secondNumber_textBox.Size = new Size(150, 31);
            secondNumber_textBox.TabIndex = 4;
            secondNumber_textBox.TextChanged += secondNumber_textBox_TextChanged;
            // 
            // Result_textBox
            // 
            Result_textBox.Location = new Point(559, 285);
            Result_textBox.Margin = new Padding(2);
            Result_textBox.Name = "Result_textBox";
            Result_textBox.ReadOnly = true;
            Result_textBox.Size = new Size(150, 31);
            Result_textBox.TabIndex = 5;
            Result_textBox.TextChanged += Result_textBox_TextChanged;
            // 
            // add_Button
            // 
            add_Button.Location = new Point(191, 234);
            add_Button.Margin = new Padding(2);
            add_Button.Name = "add_Button";
            add_Button.Size = new Size(112, 34);
            add_Button.TabIndex = 6;
            add_Button.Text = "Add";
            add_Button.UseVisualStyleBackColor = true;
            add_Button.Click += calculate_button_Click;
            // 
            // exit_button
            // 
            exit_button.Location = new Point(414, 354);
            exit_button.Margin = new Padding(2);
            exit_button.Name = "exit_button";
            exit_button.Size = new Size(112, 34);
            exit_button.TabIndex = 7;
            exit_button.Text = "Exit";
            exit_button.UseVisualStyleBackColor = true;
            exit_button.Click += exit_button_Click;
            // 
            // subtract_Button
            // 
            subtract_Button.Location = new Point(344, 231);
            subtract_Button.Margin = new Padding(4, 4, 4, 4);
            subtract_Button.Name = "subtract_Button";
            subtract_Button.Size = new Size(118, 36);
            subtract_Button.TabIndex = 8;
            subtract_Button.Text = "Subtract";
            subtract_Button.UseVisualStyleBackColor = true;
            subtract_Button.Click += subtract_Button_Click;
            // 
            // multipy_Button
            // 
            multipy_Button.Location = new Point(511, 232);
            multipy_Button.Margin = new Padding(4, 4, 4, 4);
            multipy_Button.Name = "multipy_Button";
            multipy_Button.Size = new Size(118, 36);
            multipy_Button.TabIndex = 9;
            multipy_Button.Text = "Multiply";
            multipy_Button.UseVisualStyleBackColor = true;
            multipy_Button.Click += multipy_Button_Click;
            // 
            // divide_Button
            // 
            divide_Button.Location = new Point(691, 234);
            divide_Button.Margin = new Padding(4, 4, 4, 4);
            divide_Button.Name = "divide_Button";
            divide_Button.Size = new Size(118, 36);
            divide_Button.TabIndex = 10;
            divide_Button.Text = "Divide";
            divide_Button.UseVisualStyleBackColor = true;
            divide_Button.Click += divide_Button_Click;
            // 
            // lastCalculation_label
            // 
            lastCalculation_label.AutoSize = true;
            lastCalculation_label.Location = new Point(25, 111);
            lastCalculation_label.Margin = new Padding(4, 0, 4, 0);
            lastCalculation_label.Name = "lastCalculation_label";
            lastCalculation_label.Size = new Size(73, 25);
            lastCalculation_label.TabIndex = 11;
            lastCalculation_label.Text = "History:";
            // 
            // clear_button
            // 
            clear_button.Location = new Point(580, 354);
            clear_button.Margin = new Padding(4, 4, 4, 4);
            clear_button.Name = "clear_button";
            clear_button.Size = new Size(118, 36);
            clear_button.TabIndex = 12;
            clear_button.Text = "Clear";
            clear_button.UseVisualStyleBackColor = true;
            clear_button.Click += clear_button_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(938, 448);
            Controls.Add(clear_button);
            Controls.Add(lastCalculation_label);
            Controls.Add(divide_Button);
            Controls.Add(multipy_Button);
            Controls.Add(subtract_Button);
            Controls.Add(exit_button);
            Controls.Add(add_Button);
            Controls.Add(Result_textBox);
            Controls.Add(secondNumber_textBox);
            Controls.Add(firstNumber_textBox);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Margin = new Padding(2);
            Name = "Form1";
            Text = "Simple Calculator";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox firstNumber_textBox;
        private TextBox secondNumber_textBox;
        private TextBox Result_textBox;
        private Button add_Button;
        private Button exit_button;
        private Button subtract_Button;
        private Button multipy_Button;
        private Button divide_Button;
        private Label lastCalculation_label;
        private Button clear_button;
    }
}